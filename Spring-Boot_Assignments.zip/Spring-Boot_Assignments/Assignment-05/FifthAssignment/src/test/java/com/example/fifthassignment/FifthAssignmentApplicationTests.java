package com.example.fifthassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FifthAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
