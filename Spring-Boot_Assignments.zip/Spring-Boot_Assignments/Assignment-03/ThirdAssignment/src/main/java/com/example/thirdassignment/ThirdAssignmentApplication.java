package com.example.thirdassignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThirdAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThirdAssignmentApplication.class, args);
	}

}
