package com.example.thirdassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThirdAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
