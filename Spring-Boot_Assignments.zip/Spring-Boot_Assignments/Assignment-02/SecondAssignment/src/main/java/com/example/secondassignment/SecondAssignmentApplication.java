package com.example.secondassignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecondAssignmentApplication.class, args);
	}

}
