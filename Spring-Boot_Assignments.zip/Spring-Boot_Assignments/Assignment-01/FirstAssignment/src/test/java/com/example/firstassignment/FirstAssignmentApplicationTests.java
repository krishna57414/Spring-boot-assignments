package com.example.firstassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
